using System;
using System.IO;

class Program
{
    const int numProdutos = 4;
    const int numDias = 30;
    static string[] nomesProdutos = new string[numProdutos];
    static int[] estoque = new int[numProdutos];
    static int[,] vendas = new int[numDias, numProdutos];

    static void Main(string[] args)
    {
        int opcao;

        do
        {
            Console.Clear();
            Console.WriteLine("Menu Principal");
            Console.WriteLine("1 – Importar arquivo de produtos");
            Console.WriteLine("2 – Registrar venda");
            Console.WriteLine("3 – Relatório de vendas");
            Console.WriteLine("4 – Relatório de estoque");
            Console.WriteLine("5 – Criar arquivo de vendas");
            Console.WriteLine("6 - Sair");
            Console.Write("Escolha uma opção: ");
            opcao = int.Parse(Console.ReadLine());

            switch (opcao)
            {
                case 1:
                    ImportarArquivoProdutos();
                    break;
                case 2:
                    RegistrarVenda();
                    break;
                case 3:
                    RelatorioVendas();
                    break;
                case 4:
                    RelatorioEstoque();
                    break;
                case 5:
                    CriarArquivoVendas();
                    break;
                case 6:
                    Console.WriteLine("Saindo do programa...");
                    break;
                default:
                    Console.WriteLine("Opção inválida. Tente novamente.");
                    break;
            }

            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();

        } while (opcao != 6);
    }

    // Importa os dados dos produtos de um arquivo
    static void ImportarArquivoProdutos()
    {
        Console.Write("Digite o nome do arquivo de produtos: ");
        string nomeArquivo = Console.ReadLine();

        try
        {
            string[] linhas = File.ReadAllLines(nomeArquivo);
            for (int i = 0; i < numProdutos; i++)
            {
                string[] dados = linhas[i].Split(',');
                nomesProdutos[i] = dados[0];
                estoque[i] = int.Parse(dados[1]);
            }
            Console.WriteLine("Produtos importados com sucesso.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Erro ao importar arquivo: " + ex.Message);
        }
    }

    // Registra uma venda, garantindo que não ultrapasse o estoque
    static void RegistrarVenda()
    {
        Console.Write("Digite o número do produto (1-4): ");
        int produto = int.Parse(Console.ReadLine()) - 1;
        Console.Write("Digite o dia do mês (1-30): ");
        int dia = int.Parse(Console.ReadLine()) - 1;
        Console.Write("Digite a quantidade vendida: ");
        int quantidade = int.Parse(Console.ReadLine());

        if (produto < 0 || produto >= numProdutos || dia < 0 || dia >= numDias)
        {
            Console.WriteLine("Produto ou dia inválido.");
            return;
        }

        if (quantidade <= estoque[produto])
        {
            vendas[dia, produto] += quantidade;
            estoque[produto] -= quantidade;
            Console.WriteLine("Venda registrada com sucesso.");
        }
        else
        {
            Console.WriteLine("Quantidade de venda excede o estoque disponível.");
        }
    }

    // Gera um relatório das vendas mensais
    static void RelatorioVendas()
    {
        Console.WriteLine("Relatório de Vendas:");
        Console.Write("Dia");
        for (int i = 0; i < numProdutos; i++)
        {
            Console.Write($"\t{nomesProdutos[i]}");
        }
        Console.WriteLine();

        for (int dia = 0; dia < numDias; dia++)
        {
            Console.Write($"{dia + 1}");
            for (int produto = 0; produto < numProdutos; produto++)
            {
                Console.Write($"\t{vendas[dia, produto]}");
            }
            Console.WriteLine();
        }
    }

    // Gera um relatório do estoque atual
    static void RelatorioEstoque()
    {
        Console.WriteLine("Relatório de Estoque Atualizado:");
        for (int i = 0; i < numProdutos; i++)
        {
            Console.WriteLine($"{nomesProdutos[i]} {estoque[i]}");
        }
    }

    // Cria um arquivo com o total de vendas por produto
    static void CriarArquivoVendas()
    {
        Console.Write("Digite o nome do arquivo para salvar as vendas: ");
        string nomeArquivo = Console.ReadLine();

        try
        {
            using (StreamWriter writer = new StreamWriter(nomeArquivo))
            {
                for (int i = 0; i < numProdutos; i++)
                {
                    int totalVendas = 0;
                    for (int dia = 0; dia < numDias; dia++)
                    {
                        totalVendas += vendas[dia, i];
                    }
                    writer.WriteLine($"{nomesProdutos[i]} {totalVendas}");
                }
            }
            Console.WriteLine("Arquivo de vendas criado com sucesso.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Erro ao criar arquivo: " + ex.Message);
        }
    }
}
